#hugging face models
EMBEDDING_MODELS = {
    "MiniLM": "sentence-transformers/all-MiniLM-L6-v2",
    "MPNet": "sentence-transformers/all-mpnet-base-v2"
}

#vector databases
VECTOR_STORES = ["FAISS", "Chroma"]

#default number of documents that can be retrieved
DEFAULT_TOP_K = 3
