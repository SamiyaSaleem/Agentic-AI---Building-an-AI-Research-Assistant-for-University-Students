import tkinter as tk
from tkinter import filedialog, ttk
import os
from config import EMBEDDING_MODELS, VECTOR_STORES

class SemanticSearchGUI:
    def __init__(self, root, query_search):
        self.root = root
        self.query_search = query_search
        self.root.title("AI Research Assistant - Semantic Search")
        self.root.geometry("900x650")
        self.root.configure(bg="#006b5b")

        self.dataset_path = None

        #style
        style = ttk.Style()
        style.theme_use("clam")

        #buttons
        style.configure("TButton",
                        font=("Segoe UI", 10, "bold"),
                        padding=6)

        #labels
        style.configure("TLabel",
                        font=("Segoe UI", 10))

        # header
        style.configure("Header.TLabel",
                font=("Segoe UI", 16, "bold"),
                foreground="white",
                background="#006b5b")

        header = ttk.Label(
            root,
            text="AI Research Assistant - Semantic Search Engine",
            style="Header.TLabel",
            anchor="center"
        )
        header.pack(pady=15)

        #frame style
        style.configure("White.TLabelframe",
                        background="white")
        style.configure("White.TLabelframe.Label",
                        foreground="#006b5b",
                        background="white",
                        font=("Segoe UI", 12, "bold"))

        #dataset frame
        dataset_frame = ttk.LabelFrame(root, text=" Dataset Configuration ", padding=15, style="White.TLabelframe")
        dataset_frame.pack(fill="x", padx=20, pady=10)

        ttk.Button(
            dataset_frame,
            text="Select Dataset Folder",
            command=self.loading_dataset
        ).grid(row=0, column=0, padx=10, pady=5)

        self.dataset_label = ttk.Label(dataset_frame, text="No dataset selected")
        self.dataset_label.grid(row=0, column=1, padx=10)

        #model frame
        model_frame = ttk.LabelFrame(root, text=" Model & Vector Store Settings ", padding=15, style="White.TLabelframe")
        model_frame.pack(fill="x", padx=20, pady=10)

        ttk.Label(model_frame, text="Embedding Model:").grid(row=0, column=0, sticky="w", padx=5)

        self.embedding_var = tk.StringVar()
        self.embedding_var.set(list(EMBEDDING_MODELS.keys())[0])

        embedding_dropdown = ttk.Combobox(
            model_frame,
            textvariable=self.embedding_var,
            values=list(EMBEDDING_MODELS.keys()),
            state="readonly",
            width=25
        )
        embedding_dropdown.grid(row=0, column=1, padx=10, pady=5)

        ttk.Label(model_frame, text="Vector Database:").grid(row=1, column=0, sticky="w", padx=5)

        self.vector_store_var = tk.StringVar()
        self.vector_store_var.set(VECTOR_STORES[0])

        vector_dropdown = ttk.Combobox(
            model_frame,
            textvariable=self.vector_store_var,
            values=VECTOR_STORES,
            state="readonly",
            width=25
        )
        vector_dropdown.grid(row=1, column=1, padx=10, pady=5)

        #search frame
        search_frame = ttk.LabelFrame(root, text=" Semantic Search ", padding=15, style="White.TLabelframe")
        search_frame.pack(fill="x", padx=20, pady=10)

        ttk.Label(search_frame, text="Enter Query:").grid(row=0, column=0, sticky="w")

        self.query_entry = ttk.Entry(search_frame, width=70)
        self.query_entry.grid(row=0, column=1, padx=10, pady=5)

        ttk.Label(search_frame, text="Top-K Results:").grid(row=1, column=0, sticky="w")

        self.topk_entry = ttk.Entry(search_frame, width=10)
        self.topk_entry.insert(0, "3")
        self.topk_entry.grid(row=1, column=1, sticky="w", padx=10)

        ttk.Button(
            search_frame,
            text="Search",
            command=self.search
        ).grid(row=2, column=1, pady=10, sticky="w")

        #result frame
        results_frame = ttk.LabelFrame(root, text=" Retrieval Results ", padding=15, style="White.TLabelframe")
        results_frame.pack(fill="both", expand=True, padx=20, pady=10)

        self.results_box = tk.Text(
            results_frame,
            wrap="word",
            font=("Consolas", 10),
            bg="white",
            relief="solid",
            borderwidth=1
        )
        self.results_box.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(
            results_frame,
            command=self.results_box.yview
        )
        scrollbar.pack(side="right", fill="y")

        self.results_box.config(yscrollcommand=scrollbar.set)

    #loading of dataset
    def loading_dataset(self):
        path = filedialog.askdirectory()
        if path:
            self.dataset_path = path
            files = [f for f in os.listdir(path) if f.endswith(".txt")]

            total_size = sum(
                os.path.getsize(os.path.join(path, f))
                for f in files
            )

            size_kb = total_size / 1024

            self.dataset_label.config(
                text=f"{len(files)} documents loaded | Size: {size_kb:.2f} KB"
            )

    #search function
    def search(self):
        if not self.dataset_path:
            self.results_box.delete("1.0", tk.END)
            self.results_box.insert(tk.END, "Please select a dataset folder first.")
            return

        try:
            top_k = int(self.topk_entry.get())
        except ValueError:
            self.results_box.delete("1.0", tk.END)
            self.results_box.insert(tk.END, "Top-K must be a number.")
            return

        self.results_box.delete("1.0", tk.END)
        self.results_box.insert(tk.END, "Searching... please wait.\n")
        self.root.update()

        results = self.query_search(
            self.dataset_path,
            self.embedding_var.get(),
            self.vector_store_var.get(),
            self.query_entry.get(),
            top_k
        )

        self.results_box.delete("1.0", tk.END)

        if not results:
            self.results_box.insert(tk.END, "No relevant documents found.")
        else:
            for i, r in enumerate(results, 1):
                self.results_box.insert(tk.END, f"Result {i}:\n")
                self.results_box.insert(tk.END, "-" * 80 + "\n")
                self.results_box.insert(tk.END, r + "\n\n")