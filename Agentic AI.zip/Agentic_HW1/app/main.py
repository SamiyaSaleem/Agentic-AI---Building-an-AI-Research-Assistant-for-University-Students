import os
#converts text to vectors
from langchain_huggingface import HuggingFaceEmbeddings
#vector databases
from langchain_community.vectorstores import FAISS, Chroma
from config import EMBEDDING_MODELS
import tkinter as tk
from gui import SemanticSearchGUI

def document_loading(folder_path):
    documents = []
    for file in os.listdir(folder_path):
        if file.endswith(".txt"):
            with open(os.path.join(folder_path, file), "r", encoding="utf-8") as f:
                documents.append(f.read())
    return documents

def vector_stored(documents, embedding_choice, vector_store_choice):
    #converts text into numerical vectors
    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODELS[embedding_choice]
    )

    if vector_store_choice == "FAISS":
        vector_store = FAISS.from_texts(documents, embeddings)
    else:
        vector_store = Chroma.from_texts(documents, embeddings)

    #returns vector db
    return vector_store

def query_search(folder_path, embedding_choice, vector_store_choice, query, top_k):
    documents = document_loading(folder_path)
    vector_store = vector_stored(
        documents,
        embedding_choice,
        vector_store_choice
    )
    #query embedded
    results = vector_store.similarity_search(query, k=top_k)
    return [doc.page_content for doc in results]


if __name__ == "__main__":
    root = tk.Tk()
    app = SemanticSearchGUI(root, query_search)
    root.mainloop()