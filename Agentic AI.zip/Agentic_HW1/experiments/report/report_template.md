Agentic AI
Homework – I (Phase I)
Building an AI Research Assistant for University Students

Name – Samiya Saleem
Roll no – 22I -1065
Section – A

Introduction: 
Universities are overloaded with study material: lecture notes, course outlines, research summaries, policies and FAQs. Students often struggle to find relevant information quickly. This task implements phase-1 of building an AI research assistant for university students. The goal was to design a semantic search engine that allows the AI assistant to retrieve relevant academic documents based on the meaning rather than keywords.

System Design: 
The system is divided into 3 parts:
1.	GUI Layer: It provides an easy-to-use user interface in which the users upload the dataset in txt form, selects the embedding model and type of vector database, enters the query, set top-k results and view the retrieval results. 
2.	Backend: The core engine that handles the loading of documents, generating embedding (text to vector), storing them in vector database and performs the semantic retrieval. 
3.	Configuration Layer: It stores the selectable embedding models (MiniLM, MPNet) and vector database (FAISS, Chroma). 
Technologies Used
Component	Technology
Embedding Models	Hugging Face (MiniLM, MPNet)  
Vector database 	FAISS/Chroma
GUI	Tkinter with ttk for modern layout
Backend	Langchain (embedding + vector store integration)

Implementation Details: 
•	The user uploads 10 – 15 txt documents via GUI. The system dynamically counts the number of documents uploaded and their size. 
•	User selects the embedding model between MiniLM or MPNet from dropdown. Each document gets converted into a dense vector using the selected model.
•	User selects the vector database type between FAISS (in-memory) or Chroma (persistent storage) from dropdown to store the embeddings (text to vector).
•	User enters the query and selects the top – k number of results. The system then retrieves the top-k semantically similar documents. 
•	The retrieved documents are shown in a scrollable result box, ordered by semantic relevance.

Testing & Evaluation: 
•	Dataset: 13 txt academic documents on semantic search, embeddings, vector databases, and information retrieval.
•	Tested Queries: 
o	What is semantic search?
o	Difference b/w keyword and semantic search
o	What is vector embedding?
o	Explain FAISS
o	Information retrieval process
•	Embedding models: MiniLM and MPNet
•	Vector databases: FAISS and Chroma
•	Top-k: 3 and 5

Observations:  
Query 	Embedding	Vector DB	Top-k	Observation
What is semantic search?	MiniLM	FAISS	3	First result directly defines semantic search; other results include related concepts like embeddings and indexing.
What is semantic search?	MPNet	FAISS	3	More context-aware ranking; definitions of semantic search appear higher than general information retrieval concepts.
Explain FAISS	MiniLM	Chroma	3	Retrieves documents explaining vector databases and nearest neighbor search; slightly slower than FAISS.
Explain FAISS	MPNet	Chroma	3	Most relevant technical documents appear first; faster than Chroma.

Observation Summary: 
•	MPNet produces slightly more accurate result as compared to MiniLM.
•	FAISS is fater than Chroma for in-memory retrieval.
•	Increasing top-k returns the additional documents, but relevance decreases beyond top 3 results.
•	The system successfully retrieves semantically relevant documents, not just the keyword matches. 

Conclusion: 
The semantic search module successfully implements the memory system of an AI research assistant. User upload datasets, select embedding models and vector database and perform semantic retrieval. The system also demonstrates meaningful retrieval results based on semantic similarity rather than keyword matching, it meets all phase-1 requirements.  
Screenshots


