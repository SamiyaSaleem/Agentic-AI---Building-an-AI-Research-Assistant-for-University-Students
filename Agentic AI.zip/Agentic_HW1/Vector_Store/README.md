#vector databases
VECTOR_STORES = ["FAISS", "Chroma"]
