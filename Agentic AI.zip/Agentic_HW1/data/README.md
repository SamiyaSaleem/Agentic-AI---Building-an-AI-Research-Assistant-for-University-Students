I have used 13 txt documents
Named - 
ai.txt
approximate_search.txt
cosine_similarity.txt
dense_embeddings.txt
euclidean_distance.txt
indexing.txt
information_retrieval.txt
keyword_search.txt
nearest_neighbor_search.txt
semantic_search_systems.txt
semantic_similarity.txt
sentence_transformers.txt
transformer_models.txt
